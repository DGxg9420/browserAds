def main():
    print("Hello from browserads!")


if __name__ == "__main__":
    main()
